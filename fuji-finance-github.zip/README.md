# Fuji Finance

Demonstração de controle financeiro, com saldo, lançamentos, categorias, objetivo e tutorial interativo.

## Executar localmente

```sh
python -m pip install -r requirements.txt
python build.py
python -m http.server 4173 --directory dist
```

Abra http://localhost:4173/login.html.

## Pastas

- `templates/`: páginas e componentes Jinja2.
- `static/`: JavaScript, CSS, imagens e bibliotecas.
- `dist/`: site pronto para hospedagem estática.
- `tests/`: verificações automatizadas em Node.js.

## Dados de demonstração

Os dados ficam temporariamente no sessionStorage da aba. Navegar entre as páginas mantém os dados; recarregar ou clicar em Sair apaga a demonstração. O tutorial usa dados separados, descartados ao sair ou concluir. Não há servidor de banco de dados nem autenticação nesta versão.

## Subir no GitHub

Extraia o ZIP e envie seu conteúdo para o repositório, incluindo as pastas. Não envie apenas o arquivo ZIP se quiser visualizar e editar o código pelo GitHub.

## Hospedagem

Publique o conteúdo de `dist/` na raiz de um domínio. O site usa caminhos absolutos, como `/static/` e `/login.html`. Para GitHub Pages, use um domínio próprio ou um repositório de site de usuário (`usuario.github.io`). Publicação em subpasta (`usuario.github.io/repositorio/`) exige adaptar os caminhos antes de publicar.
